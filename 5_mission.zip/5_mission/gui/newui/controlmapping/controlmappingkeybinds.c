class TutorialKeybinds extends ScriptedWidgetEventHandler
{
	protected Widget						m_Root;
	protected Widget						m_DetailsRoot;
	
	protected TutorialsMenu					m_Menu;
	
	void TutorialKeybinds(Widget parent, TutorialsMenu menu)
	{
		m_Root							= g_Game.GetWorkspace().CreateWidgets(GetLayoutName(), parent);
		m_Menu							= menu;
		
		Rebuild();
		m_Root.SetHandler(this);
	}
	
	void Rebuild()
	{
		ClearBindingPanels();

		int actionMax = 80;
		int column_index = 0;
		int item_index = 0;
		string output = "";
		string option_text = "";
		int deviceFlags = GetActiveDeviceFlags();
		TIntArray actions = new TIntArray;
		GetUApi().GetActiveInputs(actions);

		int actionCount = actions.Count();
		for (int i = 0; i < actionCount; ++i)
		{
			UAInput input = GetUApi().GetInputByID(actions.Get(i));
			if (!input)
				continue;

			if (item_index < actionMax)
			{
				output = "";
				option_text = "";
				g_Game.GetInput().GetActionDesc(actions.Get(i), option_text);

				if (SetElementTitle(input, deviceFlags, output))
				{
					column_index = Math.Floor(item_index / 21);
					Widget container = m_Root.FindAnyWidget("container" + column_index);
					if (!container)
						continue;

					Widget w = g_Game.GetWorkspace().CreateWidgets("gui/layouts/new_ui/tutorials/xbox/keybindings_panels/keybinding_panel.layout", container);
					Widget spacer = w.FindWidget("Spacer");
					TextWidget name = TextWidget.Cast(w.FindWidget("KeybindName"));
					TextWidget mod = TextWidget.Cast(spacer.FindWidget("KeybindModifier"));
					TextWidget value = TextWidget.Cast(spacer.FindWidget("KeybindButton"));

					string modifier_text = "";
					name.SetText(option_text);
					value.SetText(output);

					if (SetElementModifier(input, modifier_text))
					{
						mod.SetText(modifier_text);
					}

					name.Update();
					mod.Update();
					value.Update();
					spacer.Update();

					item_index++;
				}
			}
			else
			{
				option_text = "";
				g_Game.GetInput().GetActionDesc(actions.Get(i), option_text);
				ErrorEx("input action " + option_text + " index out of bounds!", ErrorExSeverity.INFO);
			}
		}
	}
	
	protected int GetActiveDeviceFlags()
	{
#ifdef PLATFORM_CONSOLE
		if (g_Game.GetInput().GetCurrentInputDevice() == EInputDeviceType.CONTROLLER)
		{
			return EUAINPUT_DEVICE_CONTROLLER;
		}
#endif
		return EUAINPUT_DEVICE_KEYBOARDMOUSE;
	}

	protected void ClearBindingPanels()
	{
		int columnIndex = 0;
		Widget container = m_Root.FindAnyWidget("container" + columnIndex);

		while (container)
		{
			Widget child = container.GetChildren();
			while (child)
			{
				Widget next = child.GetSibling();
				child = next;
			}

			columnIndex++;
			container = m_Root.FindAnyWidget("container" + columnIndex);
		}
	}
	
	//! assemble all active bindings at widget element
	bool SetElementTitle(UAInput pInput, int iDeviceFlags, out string output)
	{
		int a, i, countbind = 0;
	
		for (a = 0; a < pInput.AlternativeCount(); a++)
		{
			pInput.SelectAlternative(a);
			if (pInput.IsCombo())
			{
				if (pInput.BindingCount() > 0)
				{
					if (pInput.Binding(0) != 0 && pInput.CheckBindDevice(0,iDeviceFlags))
					{
						if (countbind > 0)
							output += ", ";
						
						output += GetUApi().GetButtonName(pInput.Binding(0));
						countbind++;
						
						for (i = 1; i < pInput.BindingCount(); i++)
						{
							if (pInput.Binding(i) != 0)
							{
								output += " + " + GetUApi().GetButtonName(pInput.Binding(i));
								countbind++;
							}
						}
						
					}
				}
			}
			else
			{
				if (pInput.BindingCount() > 0)
				{
					if (pInput.Binding(0) != 0 && pInput.CheckBindDevice(0,iDeviceFlags))
					{
						if (countbind > 0)
							output += ", ";

						output += GetUApi().GetButtonName(pInput.Binding(0));
						countbind++;
					}
				}
			}
			
		}
		
		return (countbind > 0);
	}
	
	//! Determine the active limiter of the bindings (currently unreliable, multiple limiters can be active on key combos!)
	bool SetElementModifier(UAInput pInput, out string output)
	{
		if (pInput.IsLimited())
		{
			if (pInput.IsPressLimit())
			{
				output = "#keybind_press";
			}
			if (pInput.IsReleaseLimit())
			{
				output = "#keybind_release";
			}
			if (pInput.IsHoldLimit())
			{
				output = "#keybind_hold";
			}
			if (pInput.IsHoldBeginLimit())
			{
				output = "#keybind_holdbegin";
			}
			if (pInput.IsClickLimit())
			{
				output = "#keybind_click";
			}
			if (pInput.IsDoubleClickLimit())
			{
				output = "#keybind_doubletap";
			}
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	void ~TutorialKeybinds()
	{
		
	}
	
	string GetLayoutName()
	{
		return "gui/layouts/new_ui/tutorials/xbox/keybinds_tab.layout";
	}
}
