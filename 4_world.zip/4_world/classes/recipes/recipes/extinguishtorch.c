class ExtinguishTorch extends RecipeBase	
{	
	override void Init()
	{
		m_Name = "#extinguish";
		m_IsInstaRecipe = false;//should this recipe be performed instantly without animation
		m_AnimationLength = 0.5;//animation length in relative time units
		m_Specialty = 0.02;// value > 0 for roughness, value < 0 for precision
		
		
		//conditions
		m_MinDamageIngredient[0] = -1;//-1 = disable check
		m_MaxDamageIngredient[0] = 3;//-1 = disable check
		
		m_MinQuantityIngredient[0] = -1;//-1 = disable check
		m_MaxQuantityIngredient[0] = -1;//-1 = disable check
		
		m_MinDamageIngredient[1] = -1;//-1 = disable check
		m_MaxDamageIngredient[1] = 3;//-1 = disable check
		//TODO SS 2.0 should modify MinQuantity of liquid
		m_MinQuantityIngredient[1] = 100;//-1 = disable check
		m_MaxQuantityIngredient[1] = -1;//-1 = disable check
		//----------------------------------------------------------------------------------------------------------------------
		
		//INGREDIENTS
		//ingredient 1
		InsertIngredient(0,"Torch");//you can insert multiple ingredients this way
		InsertIngredient(0,"Broom");//you can insert multiple ingredients this way

		m_IngredientAddHealth[0] = 0;// 0 = do nothing
		m_IngredientSetHealth[0] = -1; // -1 = do nothing
		m_IngredientAddQuantity[0] = 0;// 0 = do nothing
		m_IngredientDestroy[0] = false;//true = destroy, false = do nothing
		m_IngredientUseSoftSkills[0] = false;// set 'true' to allow modification of the values by softskills on this ingredient
		
		//ingredient 2
		InsertIngredient(1,"Pot");//you can insert multiple ingredients this way
		InsertIngredient(1,"CanisterGasoline");//you can insert multiple ingredients this way
		InsertIngredient(1,"DisinfectantAlcohol");//you can insert multiple ingredients this way
		InsertIngredient(1,"Canteen");//you can insert multiple ingredients this way
		InsertIngredient(1,"WaterBottle");//you can insert multiple ingredients this way
		InsertIngredient(1,"FilteringBottle");//you can insert multiple ingredients this way
		InsertIngredient(1,"GlassBottle");//you can insert multiple ingredients this way
		InsertIngredient(1,"WineBottle");//you can insert multiple ingredients this way
		InsertIngredient(1,"WaterPouch_ColorBase");//you can insert multiple ingredients this way
		InsertIngredient(1,"Barrel_ColorBase");//you can insert multiple ingredients this way
		InsertIngredient(1,"AyranBottle");//you can insert multiple ingredients this way
		
		m_IngredientAddHealth[1] = 0;// 0 = do nothing
		m_IngredientSetHealth[1] = -1; // -1 = do nothing
		m_IngredientAddQuantity[1] = -100;// 0 = do nothing
		m_IngredientDestroy[1] = false;// false = do nothing
		m_IngredientUseSoftSkills[1] = true;// set 'true' to allow modification of the values by softskills on this ingredient
		//----------------------------------------------------------------------------------------------------------------------
		
		//result1
		//AddResult("");//add results here

		m_ResultSetFullQuantity[0] = false;//true = set full quantity, false = do nothing
		m_ResultSetQuantity[0] = -1;//-1 = do nothing
		m_ResultSetHealth[0] = -1;//-1 = do nothing
		m_ResultInheritsHealth[0] = -1;// (value) == -1 means do nothing; a (value) >= 0 means this result will inherit health from ingredient number (value);(value) == -2 means this result will inherit health from all ingredients averaged(result_health = combined_health_of_ingredients / number_of_ingredients)
		m_ResultInheritsColor[0] = -1;// (value) == -1 means do nothing; a (value) >= 0 means this result classname will be a composite of the name provided in AddResult method and config value "color" of ingredient (value)
		m_ResultToInventory[0] = -2;//(value) == -2 spawn result on the ground;(value) == -1 place anywhere in the players inventory, (value) >= 0 means switch position with ingredient number(value)
		m_ResultUseSoftSkills[0] = false;// set 'true' to allow modification of the values by softskills on this result
		m_ResultReplacesIngredient[0] = -1;// value == -1 means do nothing; a value >= 0 means this result will transfer item propertiesvariables, attachments etc.. from an ingredient value
	}

	override bool CanDo(ItemBase ingredients[], PlayerBase player)//final check for recipe's validity
	{
		FlammableBase target = FlammableBase.Cast(ingredients[0]);
		ItemBase container = ingredients[1];
		
		if ( container.GetLiquidType() & (GROUP_LIQUID_BLOOD | LIQUID_WATER | LIQUID_BEER) && !container.GetIsFrozen() )
		{
			return target.IsIgnited();
		}
		return false;
	}

	override void Do(ItemBase ingredients[], PlayerBase player,array<ItemBase> results, float specialty_weight)//gets called upon recipe's completion
	{
		ItemBase ingredient1;
		Class.CastTo(ingredient1, ingredients[0]);
		if (ingredient1.HasEnergyManager())
		{
			ingredient1.GetCompEM().SwitchOff();
			ingredient1.SetWetMax();
		}
	}
};
