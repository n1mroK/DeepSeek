class PlayerSpawnDataInterpreted
{
	
}