class ConstructionPartRebuildInvertedTypeData : ConstructionPartRebuildTypeData
{
	
}