class ConstructionPartRebuildReversibleBaseTypeData : ConstructionPartRebuildTypeData
{
	
}