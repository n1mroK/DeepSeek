class ConstructionPartRebuildTypeData : ConstructionPartTypeData
{
	
}