class ActionInput_Basic
{
} 

