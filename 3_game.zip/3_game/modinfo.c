class ModInfo
{
	proto owned string GetName();
	proto owned string GetPicture();
	proto owned string GetLogo();
	proto owned string GetLogoSmall();
	proto owned string GetLogoOver(); //hover-over logo variant
	proto owned string GetTooltip();
	proto owned string GetOverview(); //description
	proto owned string GetAction();
	proto owned string GetAuthor();
	proto owned string GetVersion();
	proto bool GetDefault();
	proto bool GetIsDLC();
	proto bool GetIsOwned(); // owned & installed (it is possible this returns false even though owned when it is not installed)
	proto EDLCId GetDLCID();
	proto void GoToStore();
	
	static const string DEFAULT_PICTURE = "Gui/textures/modlogo_default_co.edds";
	static const string DEFAULT_LOGO = "Gui/textures/modlogo_default_co.edds";
	static const string DEFAULT_LOGO_SMALL = "Gui/textures/modlogo_default_co.edds";
	static const string DEFAULT_LOGO_OVER = "Gui/textures/modlogo_default_hover_co.edds";
	static const string DEFAULT_OVERVIEW = "";
	
	[Obsolete("1.30: no replacement")]
	static string GetDLCImage(string name)
	{
		string imagePath;
		switch (name)
		{
			case "nasdara":
			case "badlands":
			{
				imagePath = "gui/textures/dlc_panel_badlands.edds";
				break;
			}
			case "frostline":
			{
				imagePath = "gui/textures/dlc_panel_frostline.edds";
				break;
			}
			default:
			{
				imagePath = "set:dayz_gui image:ProgressDayZFull";
				break;
			}
		}
		
		return imagePath;
	}
}