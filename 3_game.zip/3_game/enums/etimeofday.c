enum ETimeOfDay
{
	Day,
	Night,
}