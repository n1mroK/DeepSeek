enum EPlayerStates
{
	ALIVE,
	DEAD,
}