class DayZAnimalType extends DayZCreatureAIType
{
	
}