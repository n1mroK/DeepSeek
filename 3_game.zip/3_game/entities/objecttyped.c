class ObjectTyped extends Object
{
	
};
